package com.example.voicereminder;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ReminderStore {
    private static final String PREFS = "voice_reminder_data";
    private static final String KEY_ITEMS = "items";
    private static final String KEY_NEXT_ID = "next_id";

    private ReminderStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static synchronized List<Reminder> getAll(Context context) {
        ArrayList<Reminder> result = new ArrayList<>();
        String raw = prefs(context).getString(KEY_ITEMS, "[]");
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                result.add(new Reminder(
                        item.optInt("id", i + 1),
                        clamp(item.optInt("hour", 9), 0, 23),
                        clamp(item.optInt("minute", 0), 0, 59),
                        clamp(item.optInt("repeat", Reminder.ONCE), Reminder.ONCE, Reminder.WEEKENDS),
                        item.optString("text", "Напоминание"),
                        item.optBoolean("enabled", true)
                ));
            }
        } catch (Exception ignored) {
            // If stored data is damaged, return an empty list rather than crashing the app.
        }
        return result;
    }

    public static synchronized void saveAll(Context context, List<Reminder> reminders) {
        JSONArray array = new JSONArray();
        for (Reminder reminder : reminders) {
            try {
                JSONObject item = new JSONObject();
                item.put("id", reminder.id);
                item.put("hour", reminder.hour);
                item.put("minute", reminder.minute);
                item.put("repeat", reminder.repeatMode);
                item.put("text", reminder.text);
                item.put("enabled", reminder.enabled);
                array.put(item);
            } catch (Exception ignored) {
                // Individual invalid entries are skipped.
            }
        }
        prefs(context).edit().putString(KEY_ITEMS, array.toString()).apply();
    }

    public static synchronized void put(Context context, Reminder reminder) {
        List<Reminder> items = getAll(context);
        boolean replaced = false;
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).id == reminder.id) {
                items.set(i, reminder);
                replaced = true;
                break;
            }
        }
        if (!replaced) items.add(reminder);
        saveAll(context, items);
    }

    public static synchronized Reminder find(Context context, int id) {
        for (Reminder reminder : getAll(context)) {
            if (reminder.id == id) return reminder;
        }
        return null;
    }

    public static synchronized void remove(Context context, int id) {
        List<Reminder> items = getAll(context);
        ArrayList<Reminder> kept = new ArrayList<>();
        for (Reminder reminder : items) {
            if (reminder.id != id) kept.add(reminder);
        }
        saveAll(context, kept);
    }

    public static synchronized int nextId(Context context) {
        SharedPreferences p = prefs(context);
        int id = p.getInt(KEY_NEXT_ID, 1);
        if (id < 1 || id > 1_000_000) id = 1;
        p.edit().putInt(KEY_NEXT_ID, id + 1).apply();
        return id;
    }

    public static synchronized void sortByTime(List<Reminder> reminders) {
        Collections.sort(reminders, (a, b) -> {
            int aTime = a.hour * 60 + a.minute;
            int bTime = b.hour * 60 + b.minute;
            if (a.enabled != b.enabled) return a.enabled ? -1 : 1;
            return Integer.compare(aTime, bTime);
        });
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
