package com.example.voicereminder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    public static final String ACTION_FIRE_REMINDER = "com.example.voicereminder.FIRE_REMINDER";
    public static final String EXTRA_REMINDER_ID = "reminder_id";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !ACTION_FIRE_REMINDER.equals(intent.getAction())) return;

        int id = intent.getIntExtra(EXTRA_REMINDER_ID, -1);
        Reminder reminder = ReminderStore.find(context, id);
        if (reminder == null || !reminder.enabled) return;

        if (reminder.repeatMode == Reminder.ONCE) {
            ReminderStore.remove(context, reminder.id);
        } else {
            ReminderScheduler.schedule(context, reminder);
        }

        Intent serviceIntent = new Intent(context, SpeechService.class);
        serviceIntent.setAction(SpeechService.ACTION_SPEAK);
        serviceIntent.putExtra(SpeechService.EXTRA_TEXT, reminder.text);
        serviceIntent.putExtra(SpeechService.EXTRA_TITLE, "Напоминание");
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent);
            } else {
                context.startService(serviceIntent);
            }
        } catch (RuntimeException ignored) {
            // Android may refuse a service start on heavily restricted devices.
            // The alarm itself still arrives and is retained in the system alarm history.
        }
    }
}
