package com.example.voicereminder;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;

import java.util.Calendar;
import java.util.List;

public final class ReminderScheduler {
    private ReminderScheduler() {}

    public static boolean hasExactAlarmPermission(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        return manager != null && manager.canScheduleExactAlarms();
    }

    public static void schedule(Context context, Reminder reminder) {
        cancel(context, reminder.id);
        if (!reminder.enabled) return;

        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;

        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.setAction(AlarmReceiver.ACTION_FIRE_REMINDER);
        intent.setData(Uri.parse("voicereminder://reminder/" + reminder.id));
        intent.putExtra(AlarmReceiver.EXTRA_REMINDER_ID, reminder.id);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                reminder.id,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        long triggerAt = nextTriggerTime(reminder, System.currentTimeMillis());
        try {
            if (hasExactAlarmPermission(context)) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent);
            } else {
                // Fallback: the reminder remains scheduled, but Android may deliver it later.
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent);
            }
        } catch (SecurityException exception) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent);
        }
    }

    public static void cancel(Context context, int id) {
        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.setAction(AlarmReceiver.ACTION_FIRE_REMINDER);
        intent.setData(Uri.parse("voicereminder://reminder/" + id));
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                id,
                intent,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
        );
        if (pendingIntent != null) {
            AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (manager != null) manager.cancel(pendingIntent);
            pendingIntent.cancel();
        }
    }

    public static void scheduleAll(Context context) {
        List<Reminder> reminders = ReminderStore.getAll(context);
        for (Reminder reminder : reminders) {
            if (reminder.enabled) schedule(context, reminder);
            else cancel(context, reminder.id);
        }
    }

    public static long nextTriggerTime(Reminder reminder, long nowMillis) {
        Calendar candidate = Calendar.getInstance();
        candidate.setTimeInMillis(nowMillis);
        candidate.set(Calendar.HOUR_OF_DAY, reminder.hour);
        candidate.set(Calendar.MINUTE, reminder.minute);
        candidate.set(Calendar.SECOND, 0);
        candidate.set(Calendar.MILLISECOND, 0);

        for (int offset = 0; offset <= 7; offset++) {
            if (offset > 0) candidate.add(Calendar.DAY_OF_YEAR, 1);
            int day = candidate.get(Calendar.DAY_OF_WEEK);
            boolean allowed;
            if (reminder.repeatMode == Reminder.ONCE) {
                allowed = true;
            } else if (reminder.repeatMode == Reminder.DAILY) {
                allowed = true;
            } else if (reminder.repeatMode == Reminder.WEEKDAYS) {
                allowed = day >= Calendar.MONDAY && day <= Calendar.FRIDAY;
            } else {
                allowed = day == Calendar.SATURDAY || day == Calendar.SUNDAY;
            }

            if (allowed && candidate.getTimeInMillis() > nowMillis) {
                return candidate.getTimeInMillis();
            }
        }

        // Defensive fallback; this should only be reached for corrupted repeat settings.
        candidate.setTimeInMillis(nowMillis + 24L * 60L * 60L * 1000L);
        candidate.set(Calendar.HOUR_OF_DAY, reminder.hour);
        candidate.set(Calendar.MINUTE, reminder.minute);
        candidate.set(Calendar.SECOND, 0);
        candidate.set(Calendar.MILLISECOND, 0);
        return candidate.getTimeInMillis();
    }
}
