package com.example.voicereminder;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_NOTIFICATIONS = 2001;

    private static final int BG = Color.rgb(13, 17, 23);
    private static final int PANEL = Color.rgb(22, 29, 39);
    private static final int PANEL_ALT = Color.rgb(27, 36, 47);
    private static final int TEXT = Color.rgb(239, 244, 247);
    private static final int MUTED = Color.rgb(157, 171, 183);
    private static final int ACCENT = Color.rgb(139, 227, 194);
    private static final int BORDER = Color.rgb(48, 61, 73);

    private LinearLayout page;
    private LinearLayout remindersContainer;
    private TextView permissionStatus;
    private TextView sectionCount;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildScreen();
        refreshScreen();
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean exactAllowed = ReminderScheduler.hasExactAlarmPermission(this);
        android.content.SharedPreferences p = getSharedPreferences("voice_settings", MODE_PRIVATE);
        boolean wasAllowed = p.getBoolean("exact_alarm_was_allowed", exactAllowed);
        if (exactAllowed != wasAllowed) {
            // Permission changes can cancel Android alarms; restore the saved schedule.
            ReminderScheduler.scheduleAll(this);
        }
        p.edit().putBoolean("exact_alarm_was_allowed", exactAllowed).apply();
        if (page != null) refreshScreen();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(18), dp(20), dp(32));
        scroll.addView(page, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        setContentView(scroll);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout heading = new LinearLayout(this);
        heading.setOrientation(LinearLayout.VERTICAL);
        TextView eyebrow = label("ГОЛОСОВОЙ ПОМОЩНИК", 11, ACCENT, true);
        eyebrow.setLetterSpacing(0.12f);
        heading.addView(eyebrow);
        TextView title = label("Напомню. И скажу вслух.", 27, TEXT, true);
        title.setPadding(0, dp(5), 0, 0);
        heading.addView(title);
        TextView subtitle = label("Твои дела — в нужное время.", 14, MUTED, false);
        subtitle.setPadding(0, dp(6), 0, 0);
        heading.addView(subtitle);
        header.addView(heading, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        Button settings = smallButton("⚙");
        settings.setContentDescription("Настройки голоса");
        header.addView(settings, new LinearLayout.LayoutParams(dp(48), dp(48)));
        settings.setOnClickListener(v -> openVoiceSettings());
        page.addView(header);

        View spacer = new View(this);
        page.addView(spacer, new LinearLayout.LayoutParams(1, dp(22)));

        LinearLayout permissionCard = panel(PANEL);
        permissionCard.setOrientation(LinearLayout.VERTICAL);
        TextView permissionTitle = label("Проверка доступа", 16, TEXT, true);
        permissionCard.addView(permissionTitle);
        permissionStatus = label("", 13, MUTED, false);
        permissionStatus.setPadding(0, dp(7), 0, dp(12));
        permissionCard.addView(permissionStatus);
        Button permissionButton = secondaryButton("Настроить разрешения");
        permissionButton.setOnClickListener(v -> openPermissionSetup());
        permissionCard.addView(permissionButton, matchWrap());
        page.addView(permissionCard, matchWrap());

        Button addButton = primaryButton("＋   Добавить напоминание");
        LinearLayout.LayoutParams addParams = matchWrap();
        addParams.topMargin = dp(18);
        page.addView(addButton, addParams);
        addButton.setOnClickListener(v -> openReminderEditor(null));

        LinearLayout section = new LinearLayout(this);
        section.setGravity(Gravity.CENTER_VERTICAL);
        section.setOrientation(LinearLayout.HORIZONTAL);
        section.setPadding(0, dp(26), 0, dp(12));
        TextView sectionTitle = label("ТВОИ НАПОМИНАНИЯ", 12, MUTED, true);
        sectionTitle.setLetterSpacing(0.1f);
        section.addView(sectionTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        sectionCount = label("0", 12, ACCENT, true);
        section.addView(sectionCount);
        page.addView(section);

        remindersContainer = new LinearLayout(this);
        remindersContainer.setOrientation(LinearLayout.VERTICAL);
        page.addView(remindersContainer, matchWrap());

        TextView footer = label("Голос использует системный движок синтеза речи Android. Для русского произношения установи русский голос в настройках телефона.", 12, MUTED, false);
        footer.setLineSpacing(dp(3), 1f);
        footer.setPadding(dp(2), dp(22), dp(2), 0);
        page.addView(footer);
    }

    private void refreshScreen() {
        if (remindersContainer == null) return;
        boolean exact = ReminderScheduler.hasExactAlarmPermission(this);
        boolean notifications = Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;

        String exactLine = exact
                ? "✓ Точное время разрешено"
                : "! Не разрешён доступ «Будильники и напоминания» — время может быть неточным.";
        String notificationLine = notifications
                ? "✓ Системные уведомления разрешены"
                : "! Уведомления отключены. Голос может прозвучать, но карточка уведомления не появится.";
        permissionStatus.setText(exactLine + "\n" + notificationLine);
        permissionStatus.setTextColor(exact && notifications ? ACCENT : MUTED);

        remindersContainer.removeAllViews();
        List<Reminder> all = ReminderStore.getAll(this);
        ReminderStore.sortByTime(all);
        int activeCount = 0;
        for (Reminder reminder : all) if (reminder.enabled) activeCount++;
        sectionCount.setText(String.valueOf(activeCount));

        if (all.isEmpty()) {
            LinearLayout empty = panel(PANEL);
            empty.setOrientation(LinearLayout.VERTICAL);
            empty.setGravity(Gravity.CENTER);
            TextView icon = label("◷", 34, ACCENT, true);
            empty.addView(icon);
            TextView emptyTitle = label("Пока нет напоминаний", 17, TEXT, true);
            emptyTitle.setPadding(0, dp(8), 0, dp(4));
            empty.addView(emptyTitle);
            TextView emptySub = label("Нажми кнопку выше и добавь первую фразу.", 13, MUTED, false);
            emptySub.setGravity(Gravity.CENTER);
            empty.addView(emptySub);
            remindersContainer.addView(empty, matchWrap());
        } else {
            for (Reminder reminder : all) {
                View card = createReminderCard(reminder);
                LinearLayout.LayoutParams params = matchWrap();
                params.bottomMargin = dp(10);
                remindersContainer.addView(card, params);
            }
        }
    }

    private View createReminderCard(Reminder reminder) {
        LinearLayout card = panel(PANEL);
        card.setOrientation(LinearLayout.VERTICAL);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView time = label(String.format(Locale.getDefault(), "%02d:%02d", reminder.hour, reminder.minute), 28,
                reminder.enabled ? ACCENT : MUTED, true);
        top.addView(time, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        Switch enabled = new Switch(this);
        enabled.setChecked(reminder.enabled);
        enabled.setOnCheckedChangeListener((button, checked) -> {
            reminder.enabled = checked;
            ReminderStore.put(this, reminder);
            if (checked) ReminderScheduler.schedule(this, reminder);
            else ReminderScheduler.cancel(this, reminder.id);
            refreshScreen();
        });
        top.addView(enabled);
        card.addView(top);

        TextView message = label(reminder.text, 16, reminder.enabled ? TEXT : MUTED, false);
        message.setPadding(0, dp(7), 0, dp(8));
        message.setLineSpacing(dp(2), 1f);
        card.addView(message);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        TextView repeat = label(repeatName(reminder.repeatMode), 12, MUTED, false);
        bottom.addView(repeat, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        Button edit = textButton("Изменить");
        edit.setOnClickListener(v -> openReminderEditor(reminder));
        bottom.addView(edit);
        Button delete = textButton("Удалить");
        delete.setTextColor(Color.rgb(255, 145, 145));
        delete.setOnClickListener(v -> confirmDelete(reminder));
        bottom.addView(delete);
        card.addView(bottom);
        if (!reminder.enabled) card.setAlpha(0.72f);
        return card;
    }

    private void openReminderEditor(Reminder existing) {
        Calendar now = Calendar.getInstance();
        now.add(Calendar.MINUTE, 5);
        final int[] selectedHour = { existing == null ? now.get(Calendar.HOUR_OF_DAY) : existing.hour };
        final int[] selectedMinute = { existing == null ? now.get(Calendar.MINUTE) : existing.minute };

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(4), dp(8), dp(4), 0);

        TextView messageLabel = label("Что нужно произнести?", 13, MUTED, true);
        form.addView(messageLabel);
        EditText textInput = new EditText(this);
        textInput.setTextColor(TEXT);
        textInput.setHintTextColor(MUTED);
        textInput.setHint("Например: Никита, пора выпить таблетки.");
        textInput.setTextSize(16);
        textInput.setMinLines(2);
        textInput.setMaxLines(4);
        textInput.setGravity(Gravity.TOP | Gravity.START);
        textInput.setPadding(dp(12), dp(10), dp(12), dp(10));
        textInput.setBackground(rounded(PANEL_ALT, BORDER, 12));
        if (existing != null) textInput.setText(existing.text);
        form.addView(textInput, matchWrap());

        TextView timeLabel = label("Время", 13, MUTED, true);
        timeLabel.setPadding(0, dp(16), 0, dp(6));
        form.addView(timeLabel);
        Button timeButton = secondaryButton(formatTime(selectedHour[0], selectedMinute[0]));
        form.addView(timeButton, matchWrap());
        timeButton.setOnClickListener(v -> {
            TimePickerDialog picker = new TimePickerDialog(
                    this,
                    (TimePicker view, int hourOfDay, int minute) -> {
                        selectedHour[0] = hourOfDay;
                        selectedMinute[0] = minute;
                        timeButton.setText(formatTime(hourOfDay, minute));
                    },
                    selectedHour[0],
                    selectedMinute[0],
                    true
            );
            picker.show();
        });

        TextView repeatLabel = label("Повторение", 13, MUTED, true);
        repeatLabel.setPadding(0, dp(16), 0, dp(6));
        form.addView(repeatLabel);
        Spinner repeatSpinner = new Spinner(this);
        String[] repeatOptions = {"Один раз", "Каждый день", "По будням", "По выходным"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, repeatOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        repeatSpinner.setAdapter(adapter);
        repeatSpinner.setSelection(existing == null ? Reminder.ONCE : existing.repeatMode);
        form.addView(repeatSpinner, matchWrap());

        TextView hint = label("Разовое напоминание сработает при ближайшем наступлении выбранного времени. Если время уже прошло — завтра.", 12, MUTED, false);
        hint.setPadding(0, dp(10), 0, 0);
        hint.setLineSpacing(dp(2), 1f);
        form.addView(hint);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(existing == null ? "Новое напоминание" : "Изменить напоминание")
                .setView(form)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String message = textInput.getText().toString().trim();
            if (message.isEmpty()) {
                textInput.setError("Напиши фразу для озвучивания");
                return;
            }
            Reminder reminder = existing == null
                    ? new Reminder(ReminderStore.nextId(this), selectedHour[0], selectedMinute[0],
                    repeatSpinner.getSelectedItemPosition(), message, true)
                    : new Reminder(existing.id, selectedHour[0], selectedMinute[0],
                    repeatSpinner.getSelectedItemPosition(), message, existing.enabled);
            ReminderStore.put(this, reminder);
            if (reminder.enabled) ReminderScheduler.schedule(this, reminder);
            else ReminderScheduler.cancel(this, reminder.id);
            dialog.dismiss();
            refreshScreen();
            if (!ReminderScheduler.hasExactAlarmPermission(this)) {
                Toast.makeText(this, "Напоминание сохранено. Разреши точные будильники, чтобы повысить точность времени.", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Напоминание сохранено", Toast.LENGTH_SHORT).show();
            }
        }));
        dialog.show();
    }

    private void confirmDelete(Reminder reminder) {
        new AlertDialog.Builder(this)
                .setTitle("Удалить напоминание?")
                .setMessage(reminder.text)
                .setNegativeButton("Оставить", null)
                .setPositiveButton("Удалить", (dialog, which) -> {
                    ReminderScheduler.cancel(this, reminder.id);
                    ReminderStore.remove(this, reminder.id);
                    refreshScreen();
                })
                .show();
    }

    private void openPermissionSetup() {
        String message = "Чтобы произносить фразы в нужное время, приложению нужны уведомления и доступ «Будильники и напоминания». Разрешения можно изменить в настройках Android.";
        new AlertDialog.Builder(this)
                .setTitle("Разрешения приложения")
                .setMessage(message)
                .setNegativeButton("Позже", null)
                .setPositiveButton("Продолжить", (dialog, which) -> continuePermissionSetup())
                .show();
    }

    private void continuePermissionSetup() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
            return;
        }
        openExactAlarmSettings();
    }

    private void openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                && !ReminderScheduler.hasExactAlarmPermission(this)) {
            try {
                Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } catch (Exception exception) {
                Intent fallback = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                fallback.setData(Uri.parse("package:" + getPackageName()));
                startActivity(fallback);
            }
        } else {
            Toast.makeText(this, "Все основные разрешения уже включены", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_NOTIFICATIONS) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                    && !ReminderScheduler.hasExactAlarmPermission(this)) {
                openExactAlarmSettings();
            }
            refreshScreen();
        }
    }

    private void openVoiceSettings() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(4), dp(8), dp(4), 0);

        android.content.SharedPreferences preferences = getSharedPreferences("voice_settings", MODE_PRIVATE);
        int initialRate = preferences.getInt("rate", 100);
        int initialVolume = preferences.getInt("volume", 100);

        TextView speedLabel = label("Скорость речи: " + initialRate + "%", 14, TEXT, true);
        form.addView(speedLabel);
        SeekBar speed = new SeekBar(this);
        speed.setMax(100);
        speed.setProgress(initialRate - 50);
        form.addView(speed, matchWrap());

        TextView volumeLabel = label("Громкость речи: " + initialVolume + "%", 14, TEXT, true);
        volumeLabel.setPadding(0, dp(14), 0, 0);
        form.addView(volumeLabel);
        SeekBar volume = new SeekBar(this);
        volume.setMax(100);
        volume.setProgress(initialVolume);
        form.addView(volume, matchWrap());

        TextView note = label("Громкость также зависит от уровня мультимедиа на телефоне и настроек режима «Не беспокоить».", 12, MUTED, false);
        note.setPadding(0, dp(12), 0, 0);
        form.addView(note);

        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int value = progress + 50;
                speedLabel.setText("Скорость речи: " + value + "%");
                preferences.edit().putInt("rate", value).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                volumeLabel.setText("Громкость речи: " + progress + "%");
                preferences.edit().putInt("volume", progress).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Настройки голоса")
                .setView(form)
                .setNegativeButton("Проверить голос", null)
                .setPositiveButton("Готово", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
            startSpeech("Проверка голосового напоминания. Всё работает.", "Проверка голоса");
        }));
        dialog.show();
    }

    private void startSpeech(String text, String title) {
        Intent intent = new Intent(this, SpeechService.class);
        intent.setAction(SpeechService.ACTION_SPEAK);
        intent.putExtra(SpeechService.EXTRA_TEXT, text);
        intent.putExtra(SpeechService.EXTRA_TITLE, title);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent);
            else startService(intent);
        } catch (RuntimeException exception) {
            Toast.makeText(this, "Не удалось запустить голосовой движок. Проверь настройки синтеза речи Android.", Toast.LENGTH_LONG).show();
        }
    }

    private String repeatName(int mode) {
        switch (mode) {
            case Reminder.DAILY: return "Каждый день";
            case Reminder.WEEKDAYS: return "По будням";
            case Reminder.WEEKENDS: return "По выходным";
            default: return "Один раз";
        }
    }

    private String formatTime(int hour, int minute) {
        return String.format(Locale.getDefault(), "%02d:%02d", hour, minute);
    }

    private LinearLayout panel(int color) {
        LinearLayout layout = new LinearLayout(this);
        layout.setPadding(dp(16), dp(15), dp(16), dp(15));
        layout.setBackground(rounded(color, BORDER, 18));
        return layout;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button primaryButton(String value) {
        Button button = buttonBase(value);
        button.setTextColor(Color.rgb(10, 25, 21));
        button.setTextSize(16);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setBackground(rounded(ACCENT, ACCENT, 15));
        return button;
    }

    private Button secondaryButton(String value) {
        Button button = buttonBase(value);
        button.setTextColor(TEXT);
        button.setTextSize(14);
        button.setBackground(rounded(PANEL_ALT, BORDER, 12));
        return button;
    }

    private Button smallButton(String value) {
        Button button = buttonBase(value);
        button.setTextColor(ACCENT);
        button.setTextSize(20);
        button.setBackground(rounded(PANEL_ALT, BORDER, 14));
        return button;
    }

    private Button textButton(String value) {
        Button button = buttonBase(value);
        button.setTextColor(ACCENT);
        button.setTextSize(12);
        button.setPadding(dp(8), 0, dp(8), 0);
        button.setBackground(rounded(PANEL_ALT, Color.TRANSPARENT, 10));
        return button;
    }

    private Button buttonBase(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setAllCaps(false);
        button.setMinHeight(dp(44));
        button.setPadding(dp(12), dp(7), dp(12), dp(7));
        button.setStateListAnimator(null);
        return button;
    }

    private GradientDrawable rounded(int color, int strokeColor, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        if (strokeColor != Color.TRANSPARENT) drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
