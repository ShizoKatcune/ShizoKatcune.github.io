package com.example.voicereminder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.Locale;

public class SpeechService extends Service implements TextToSpeech.OnInitListener {
    public static final String ACTION_SPEAK = "com.example.voicereminder.SPEAK";
    public static final String EXTRA_TEXT = "speech_text";
    public static final String EXTRA_TITLE = "speech_title";

    private static final String CHANNEL_ID = "voice_reminders_playback";
    private static final int NOTIFICATION_ID = 4101;

    private TextToSpeech textToSpeech;
    private String pendingText;
    private String notificationTitle = "Голосовое напоминание";
    private boolean initialized;
    private PowerManager.WakeLock wakeLock;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        textToSpeech = new TextToSpeech(getApplicationContext(), this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || !ACTION_SPEAK.equals(intent.getAction())) {
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        String text = intent.getStringExtra(EXTRA_TEXT);
        pendingText = (text == null || text.trim().isEmpty()) ? "Напоминание" : text.trim();
        String title = intent.getStringExtra(EXTRA_TITLE);
        notificationTitle = (title == null || title.trim().isEmpty())
                ? "Голосовое напоминание" : title;

        startAsForeground(createNotification(notificationTitle, pendingText));
        acquireWakeLock();
        if (initialized) speakPendingText();
        return START_NOT_STICKY;
    }

    private void startAsForeground(Notification notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            );
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Голосовые напоминания",
                NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("Показывается, пока телефон произносит напоминание");
        channel.setSound(null, null);
        channel.enableVibration(false);
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.createNotificationChannel(channel);
    }

    private Notification createNotification(String title, String text) {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                this,
                4102,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent stopIntent = new Intent(this, StopSpeechReceiver.class);
        PendingIntent stopPendingIntent = PendingIntent.getBroadcast(
                this,
                4103,
                stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        PendingIntent snoozePendingIntent = SnoozeReceiver.notificationAction(this, text);

        Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(contentIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_ALARM)
                .setColor(Color.rgb(139, 227, 194));

        builder.addAction(new Notification.Action.Builder(
                android.R.drawable.ic_lock_idle_alarm, "Отложить на 5 минут", snoozePendingIntent).build());
        builder.addAction(new Notification.Action.Builder(
                android.R.drawable.ic_media_pause, "Остановить", stopPendingIntent).build());
        return builder.build();
    }

    private void acquireWakeLock() {
        try {
            PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
            if (powerManager == null) return;
            if (wakeLock == null) {
                wakeLock = powerManager.newWakeLock(
                        PowerManager.PARTIAL_WAKE_LOCK,
                        getPackageName() + ":VoiceReminderSpeech"
                );
                wakeLock.setReferenceCounted(false);
            }
            if (!wakeLock.isHeld()) wakeLock.acquire(3L * 60L * 1000L);
        } catch (RuntimeException ignored) {
            // Audio playback can still proceed if the device refuses a wake lock.
        }
    }

    @Override
    public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS || textToSpeech == null) {
            stopSelf();
            return;
        }

        int languageResult = textToSpeech.setLanguage(new Locale("ru", "RU"));
        if (languageResult == TextToSpeech.LANG_MISSING_DATA
                || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            textToSpeech.setLanguage(Locale.getDefault());
        }

        textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {
            }

            @Override
            public void onDone(String utteranceId) {
                handler.postDelayed(() -> stopSelf(), 700);
            }

            @Override
            public void onError(String utteranceId) {
                handler.post(() -> stopSelf());
            }
        });

        initialized = true;
        speakPendingText();
    }

    private void speakPendingText() {
        if (!initialized || textToSpeech == null || pendingText == null) return;

        String text = pendingText;
        pendingText = null;

        int rate = getSharedPreferences("voice_settings", MODE_PRIVATE).getInt("rate", 100);
        int volume = getSharedPreferences("voice_settings", MODE_PRIVATE).getInt("volume", 100);
        rate = Math.max(50, Math.min(150, rate));
        volume = Math.max(0, Math.min(100, volume));

        textToSpeech.setSpeechRate(rate / 100.0f);
        Bundle parameters = new Bundle();
        parameters.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume / 100.0f);
        String utteranceId = "reminder-" + System.currentTimeMillis();
        handler.removeCallbacksAndMessages(null);
        int result = textToSpeech.speak(
                text,
                TextToSpeech.QUEUE_FLUSH,
                parameters,
                utteranceId
        );
        if (result == TextToSpeech.ERROR) {
            handler.postDelayed(() -> stopSelf(), 500);
        } else {
            handler.postDelayed(() -> stopSelf(), 2L * 60L * 1000L);
        }
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (textToSpeech != null) {
            try {
                textToSpeech.stop();
                textToSpeech.shutdown();
            } catch (RuntimeException ignored) {
            }
            textToSpeech = null;
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            try {
                wakeLock.release();
            } catch (RuntimeException ignored) {
            }
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
