package com.example.voicereminder;

public class Reminder {
    public static final int ONCE = 0;
    public static final int DAILY = 1;
    public static final int WEEKDAYS = 2;
    public static final int WEEKENDS = 3;

    public int id;
    public int hour;
    public int minute;
    public int repeatMode;
    public String text;
    public boolean enabled;

    public Reminder(int id, int hour, int minute, int repeatMode, String text, boolean enabled) {
        this.id = id;
        this.hour = hour;
        this.minute = minute;
        this.repeatMode = repeatMode;
        this.text = text;
        this.enabled = enabled;
    }
}
