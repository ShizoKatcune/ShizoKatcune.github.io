package com.example.voicereminder;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;

public class SnoozeReceiver extends BroadcastReceiver {
    public static final String ACTION_SNOOZE = "com.example.voicereminder.SNOOZE";
    public static final String ACTION_FIRE_SNOOZE = "com.example.voicereminder.FIRE_SNOOZE";
    public static final String EXTRA_TEXT = "snooze_text";
    private static final int SNOOZE_REQUEST_CODE = 700_001;

    public static PendingIntent notificationAction(Context context, String text) {
        Intent intent = new Intent(context, SnoozeReceiver.class);
        intent.setAction(ACTION_SNOOZE);
        intent.putExtra(EXTRA_TEXT, text);
        return PendingIntent.getBroadcast(
                context,
                SNOOZE_REQUEST_CODE,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    public static void scheduleFiveMinutes(Context context, String text) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;

        Intent intent = new Intent(context, SnoozeReceiver.class);
        intent.setAction(ACTION_FIRE_SNOOZE);
        intent.setData(Uri.parse("voicereminder://snooze/five-minutes"));
        intent.putExtra(EXTRA_TEXT, text);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                SNOOZE_REQUEST_CODE + 1,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        long at = System.currentTimeMillis() + 5L * 60L * 1000L;
        try {
            if (ReminderScheduler.hasExactAlarmPermission(context)) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pendingIntent);
            } else {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pendingIntent);
            }
        } catch (SecurityException exception) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pendingIntent);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        String text = intent.getStringExtra(EXTRA_TEXT);

        if (ACTION_SNOOZE.equals(action)) {
            context.stopService(new Intent(context, SpeechService.class));
            scheduleFiveMinutes(context, text == null ? "Напоминание" : text);
        } else if (ACTION_FIRE_SNOOZE.equals(action)) {
            Intent serviceIntent = new Intent(context, SpeechService.class);
            serviceIntent.setAction(SpeechService.ACTION_SPEAK);
            serviceIntent.putExtra(SpeechService.EXTRA_TEXT, text == null ? "Напоминание" : text);
            serviceIntent.putExtra(SpeechService.EXTRA_TITLE, "Отложенное напоминание");
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent);
                } else {
                    context.startService(serviceIntent);
                }
            } catch (RuntimeException ignored) {
                // Some device manufacturers apply additional background restrictions.
            }
        }
    }
}
