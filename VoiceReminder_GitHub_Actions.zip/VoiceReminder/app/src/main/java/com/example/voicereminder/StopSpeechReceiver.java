package com.example.voicereminder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class StopSpeechReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        context.stopService(new Intent(context, SpeechService.class));
    }
}
