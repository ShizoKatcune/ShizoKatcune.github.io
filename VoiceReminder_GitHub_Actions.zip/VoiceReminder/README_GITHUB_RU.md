# Сборка Voice Reminder через GitHub Actions

## 1. Создай репозиторий
1. Открой https://github.com и войди в аккаунт.
2. Нажми **+ → New repository**.
3. Назови репозиторий `VoiceReminder`.
4. Выбери **Private** (рекомендуется) и нажми **Create repository**.

## 2. Загрузи файлы проекта
1. Распакуй архив на телефоне.
2. Открой папку `VoiceReminder` — именно внутри неё находятся `settings.gradle`, `build.gradle` и папка `app`.
3. В созданном репозитории нажми **Add file → Upload files**.
4. Загрузи ВСЁ содержимое папки `VoiceReminder`, включая скрытую папку `.github` и файл workflow внутри неё. Не загружай только внешний ZIP.
5. Нажми **Commit changes**.

Важно: структура репозитория должна начинаться так:
- `.github/workflows/build-apk.yml`
- `app/`
- `gradle/`
- `build.gradle`
- `settings.gradle`

Файлы не должны оказаться во вложенной папке `VoiceReminder/VoiceReminder/`.

## 3. Запусти сборку
1. Открой вкладку **Actions** репозитория.
2. Если GitHub спросит разрешение на workflows, нажми **I understand my workflows, go ahead and enable them**.
3. Выбери **Build Android APK**.
4. Нажми **Run workflow → Run workflow**.
5. Открой появившийся запуск и дождись зелёной галочки.

## 4. Скачай APK
1. Открой завершённый запуск workflow.
2. Прокрути страницу до **Artifacts**.
3. Скачай `voice-reminder-debug-apk`.
4. Распакуй скачанный ZIP и установи `app-debug.apk` на Android. Если система спросит, разреши установку из этого источника.

## Если сборка завершилась ошибкой
Открой красный шаг в журнале, скопируй текст ошибки или пришли скриншот. Не публикуй пароли, токены или ключи доступа.

Сборка создаёт debug APK для тестирования. Она не является подписанной release-сборкой для публикации в Google Play.
